#!/bin/bash

:<<!
# ###############################################################
          综合理财平台 Oracle 巡检脚本
 操作系统：Linux,AIX
 数据库版本：Oracle 9i以上
 使用说明：
     1、必须结合initdata里的脚本一起使用。
     2、xj_ifm30_ora_screenInput.sh(本脚本)需要有执行权限。
     3、脚本直接执行即可，界面会有提示输入参数。
     4、如果aix执行异常，或者命令不支持，请将开头的 #!/bin/bash 修改为 #!/bin/ksh
 脚本所属：恒生电子股份有限公司    
# ###############################################################
!


# 脚本正文：分模块处理

# ###############################################################
#       init_param
#       初始化参数配置
# 特别说明：参数配置的先后顺序请勿调整！！！
# ###############################################################

function init_param {

DATE=`date +%Y%m%d`
YEAR=`date +%Y`


DATE1=${DATE}

# 10、目录及文件名配置
    
# 获取当前目录
CUR_PATH=$(pwd)

# 初始化数据路径
INIT_DATA_PATH=${CUR_PATH}/initdata

# 脚本执行日志文件
LOG_FILE=${CUR_PATH}/xj_ifm30_ora_${DATE}.log

# 结果文件存放目录
RESULT_PATH=${CUR_PATH}/XJ_OraResult

# 初始化数据导出日志
EXP_LOG=${CUR_PATH}/inidata_exp.log

# 数据检查结果文件
REPORT_FILE=${RESULT_PATH}/oracle_ifm30_report.html

# 导出基础数据表名文件
TABLE_NAME_FILE=${INIT_DATA_PATH}/exp_tables.txt

# 基础数据导出目录
EXP_DIR=${RESULT_PATH}/expdata  
     
# 基础数据导出目录
DMP_DIR=${RESULT_PATH}/expdata/dmp 

# 表结构文件 
IFM30_TABLE_STRUCT=${RESULT_PATH}/expdata/ifm30_table_struct.dmp


rm -f ${LOG_FILE}
rm -f ${EXP_LOG}
touch ${LOG_FILE}

}


# ###############################################################
#       connect_test
#       用户登录合法性测试
# ###############################################################


function connect_test {
clear
echo "Please enter the users infomation of the database: "
IS_CONN=0
while [ $IS_CONN -ne 1 ]
do
echo " "
read -p "1.Database user name(Any db user who has query right) :" DBCURUSR 
#echo " " 
#echo "password " 
read -p "2.Is secret(DES) password (y/n):" IS_SECRETPASSWORD
#echo  ${DBUSRPWD}
#echo " " 
case ${IS_SECRETPASSWORD} in
    y|Y|yes|Yes|YES)
IS_CONTINUE=1

while [ $IS_CONTINUE -ne 0 ]
do
read -p "3.Database user password(DES ciphertext) :" DBUSRPWD 
#echo "SecretPassword is: ${DBUSRPWD}"
   if [ "$DBUSRPWD" == "" ]; then
       echo " "
       echo "ERROR:Your password is null! Please enter the password."
       IS_PWD=0
       continue
       else
       IS_PWD=1
     fi
 DECRYPT_RESULT=$(java -jar ${INIT_DATA_PATH}/dbconfigtool.jar ${DBUSRPWD}  | tail -1 ) 
 DECRYPT_FLAG=$(echo ${DECRYPT_RESULT%//*})
 if [ ${DECRYPT_FLAG} == "Success" ]
 then
   DBUSRPWD=$(echo ${DECRYPT_RESULT#*//})
   IS_CONTINUE=0

 else
     echo "ERROR：password decrypt fail !"
     echo "  "     
     read -p "Try again (y/n):" IS_TRY_AGAIN1
     case ${IS_TRY_AGAIN1} in
       y|Y|yes|Yes|YES)
         IS_CONTINUE=1
       ;;
       n|N|no|No|NO)
       IS_CONTINUE=0
       echo "  " 
      exit;
       ;;
    esac 
 fi

 done
    ;;
    n|N|no|No|NO)
IS_PWD=0

while [ $IS_PWD -ne 1 ]
do
 oldMode=`stty -g`
       stty -echo       
 read -p "3.Database user password (invisible) :" DBUSRPWD  
 
    stty $oldMode
# echo "first is:$DBUSRPWD"
     if [ "$DBUSRPWD" == "" ]; then
       echo " "
       echo "ERROR：Your password is null! Please enter the password."
       IS_PWD=0
       continue
       else
       IS_PWD=1
     fi
done
echo "  "
    ;;
    esac         

#echo "  "
read -p "4.Database user name(must be app database user):" IFM30USER  
# 理财用户名小写转大写
IFM30USER=`echo ${IFM30USER} | tr '[:lower:]' '[:upper:]'`
#echo " "
read -p "5.Is need database service name (y/n):" IS_DBSERVICE 
case ${IS_DBSERVICE} in
    y|Y|yes|Yes|YES)
 echo "  found current database service name is :$ORACLE_SID"
 read -p "  please enter the database service name :" IFM30DBSERVICE 
 DBSERVICE=@${IFM30DBSERVICE}
    ;;
    n|N|no|No|NO)
 DBSERVICE= 
    ;;
    esac         

#echo " "
echo "6.Testing database connection ..."
echo "  $(echo show user | sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE})"

CONN_S=$(echo $(echo "select 'TRUE' from dual;" | sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} | grep -i 'TRUE' | wc -l))

#echo ${CONN_S}

if [ "$CONN_S" == "1" ]
then
 echo "  Connection success !" 
   IS_CONN=1
#   exit;
 else
   echo "  ERROR：Connection fail !"
   IS_CONN=0
echo "  "
read -p "Try again (y/n):" IS_TRY_AGAIN
case ${IS_TRY_AGAIN} in
    y|Y|yes|Yes|YES)
  
    ;;
    n|N|no|No|NO)
    echo "  "
 exit;
    ;;
    esac         
fi
done

echo " "
echo "Please choose whether or not you need to export app initdata and table DDL :  "
echo " "
read -p "Export app initdata(y/n) :" EXP_INITDATA  
echo " "
}

# ###############################################################
#       date_check
#       日期合法性测试
# ###############################################################

function date_check {

echo "Please enter the start date & end date of this checkup: "
IS_RIG=0
while [ $IS_RIG -ne 1 ]
do
IS_RIG=1
echo " "
read -p "1.Start date(YYYYMMDD):" KSRQ  
#echo " "
read -p "2.End   date(YYYYMMDD):" JSRQ 

len1=$(echo ${#KSRQ})
len2=$(echo ${#JSRQ})

if [ "$len1" -ne 8 ]
then
   echo "Format error: Start date lenth !=8  "
#   exit;
   IS_RIG=0
fi

if [ "$len2" -ne 8 ]
then
    echo "Format error: End date lenth !=8  "
#   exit;
   IS_RIG=0
fi

if [ "$KSRQ" -ge "$JSRQ" ]
then
    echo "Error: Start date >= End date "
#   exit;
IS_RIG=0
fi
done
}

# ###############################################################
#       after_connect
#       连接成功后参数录入
# ###############################################################

function after_connect {
echo " "
# 公共（默认检查）IS_CHECK_PUB=1
# 理财IS_CHECK_FINA=1
# 基金IS_CHECK_FUND=1
# 银保IS_CHECK_YBT=1
# 贵金属IS_CHECK_METAL=1
# 是否统计客户量，交易量，金额等信息（敏感）0-不统计，1-统计 IS_STATISTICS=1
IS_BUSINESS_CONFIRM=0
while [ ${IS_BUSINESS_CONFIRM} -ne 1 ]
do
IS_RIG=1
echo "Please enter the system business of this checkup: "
read -p "1.pub data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_PUB 
read -p "2.fina data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_FINA
read -p "3.fund data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_FUND
read -p "4.ybt data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_YBT
read -p "5.metal data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_METAL
read -p "6.trust data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_TRUST
read -p "7.zgdx data(option 1-yes,0-no) enter 1 or 0:" IS_CHECK_ZGDX
read -p "8.trading volume statistics(jiao yi liang tongji option 1-yes,0-no) enter 1 or 0:" IS_STATISTICS
echo " "
read -p "confirm ? (y or n): " IS_CONFIRM
case ${IS_CONFIRM} in
    y|Y|yes|Yes|YES)
 IS_BUSINESS_CONFIRM=1;
    ;;
    n|N|no|No|NO)
 IS_BUSINESS_CONFIRM=0;
    ;;
    esac         
done
}

# ###############################################################
#       init_path
#       初始化路径
# ###############################################################

function init_path {
    # 为支持重复执行，先删除前一次执行的结果
    # 创建检查结果存放目录 beg
    echo "Step 1: Create Resuilt File Dir "                          >>${LOG_FILE}
    echo "        creating dir:${RESULT_PATH} ..."                   >>${LOG_FILE}
    
    if [  -d "${RESULT_PATH}" ]; 
        then
        echo "        dir exists."                                   >>${LOG_FILE}
        echo "        trying to remove it and rebuild the dir... "   >>${LOG_FILE}
        
        rm -rf ${RESULT_PATH}    
        mkdir  ${RESULT_PATH} 
        
        else
        
        echo "        dir not exist,trying to create it..."           >>${LOG_FILE}  
           
        mkdir ${RESULT_PATH}
    fi
        echo "        dir ${RESULT_PATH} created!"                    >>${LOG_FILE}
        mkdir  ${EXP_DIR}
        echo "        dir ${EXP_DIR} created!"                        >>${LOG_FILE}
        mkdir  ${DMP_DIR}
        echo "        dir ${DMP_DIR} created!"                        >>${LOG_FILE}
    echo "           step1 ended."                                      | tee -a  ${LOG_FILE}
}

# ###############################################################
#       sub_ifm30
#       理财数据库检查
# ###############################################################

function sub_ifm30 {
	RESULT_FILE=${RESULT_PATH}/$1
	SQL_FILE=$2
	CHECK_BUSINESS=$3
    echo "           Check Business: ${CHECK_BUSINESS}"                   | tee -a  ${LOG_FILE}
    echo "        writting resuilt to: ${RESULT_PATH} "                    >>${LOG_FILE}
    echo "        usinging basesql from: ${SQL_FILE} "                     >>${LOG_FILE}
    sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} <<EOF                   >>${LOG_FILE} 

set term off termout off verify off feedback off echo off heading on pagesize 999 
set markup html on  spool on PREFORMAT OFF ENTMAP Off -
HEAD  '<TITLE> IFM30 DB Report </TITLE> -
<style type="text/css"> -
  body{font-family:Microsoft YaHei,sans-serif;font-size: 12px;line-height:140%;color:#333333; WORD-WRAP:break-word;}-
  h0 {margin:5px 0px 5px 0px;font-size:30px;line-height:32px;font-weight:900;}-
  h1 {margin:5px 0px 5px 0px;font-size:20px;line-height:22px;}-
  h2 {margin:10px 0px 5px 0px;font-size:18px;line-height:20px;}-
  h3 {margin:10px 0px 5px 0px;font-size:16px;line-height:18px;}-
  h4 {margin:10px 0px 5px 0px;font-size:14px;line-height:16px;color:#CD4F39;}-
  p  {margin:10px 0px 5px 0px;padding:0;font-size: 10px;line-height:16px;color:#B22222;}-
  hr.level1{height: 2px;;width:100%;background:#EECFA1;}-
  a {color:#1874CD}-
  br{ display:inline; line-height:5px;} -
  div{margin:0px 0px 0px 0px;color: #333333;line-height:20px;}-
  div.level1{margin:0px 0px 0px 0px;color: #333333;line-height:20px;}-
  ul.level2{list-style-type:square;line-height:18px; }- 
  ul.level3{list-style-type:square;list-style-position: inside;font-size: 12px;line-height:14px;color:#EE5C42;}-  
  table {align:left;font-family: arial, sans-serif;font-size: 12px;line-height:100%;color: #333333;border-width: 1px;border-color: #3A3A3A;border-collapse: collapse;}-
  th {border-width: 1px;padding: 4px;border-style: solid;border-color: #517994;background-color:#B2CFD8;}-
  tr:hover td {background-color:#DFEBF1;}-
  td {border-width: 1px;padding: 4px;border-style: solid;border-color: #517994;background-color:#ffffff;-
  }-
</style>' -
BODY "" -
TABLE "border='1' width='0' " -

spool ${RESULT_FILE}
@${INIT_DATA_PATH}/${SQL_FILE}
${IFM30USER}.
${IS_STATISTICS}
${YEAR}
${KSRQ}
${JSRQ}
${IFM30USER}
spool off;
set markup html off;
exit;
EOF
    echo "           checking business ${CHECK_BUSINESS} ended"                 | tee -a  ${LOG_FILE}

}

# ###############################################################
#       exp_param
#       导出相关配置信息
# ###############################################################

    # 导出相关配置信息 beg
    function exp_param {
    echo "Step 3: Export Param To Excel "                            >>${LOG_FILE}
    cd ${INIT_DATA_PATH}
    echo "        generating files to:${RESULT_PATH} "               >>${LOG_FILE}
    echo "        usinging basesql from: ${INIT_DATA_PATH} "         >>${LOG_FILE}

    sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE}  <<EOF1     >>${LOG_FILE} 2>&1

set term off termout off verify off feedback off pagesize 999 
set markup html on entmap ON spool on preformat off

prompt --------exporting tbtaskpool to tbtaskpool.xls
spool ${RESULT_PATH}/tbtaskpool.xls;
@tbtaskpool.sql ${IFM30USER}.
spool off;

prompt --------exporting tbparam to tbparam.xls
spool ${RESULT_PATH}/tbparam.xls;
@tbparam.sql ${IFM30USER}.
spool off;

prompt --------exporting index to index.xls
spool ${RESULT_PATH}/index.xls;
@index.sql ${IFM30USER}
spool off;

prompt --------exporting indexQuality to indexQuality.xls 
spool ${RESULT_PATH}/indexQuality.xls;
@indexQuality.sql ${IFM30USER}
spool off;

exit;
EOF1

echo "        export param table ended"                          >>${LOG_FILE}
echo "           step3 ended."                                    | tee -a  ${LOG_FILE}

}

# ###############################################################
#       exp_initdata
#       导出理财初始化数据
# ###############################################################

    # 导出理财初始化数据 beg
    function exp_initdata {
    echo "Step 4: Export IFM30 Init Data "                                        >>${LOG_FILE}
    case ${EXP_INITDATA} in
    y|Y|yes|Yes|YES)
    
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}' "           >>${LOG_FILE} 
        echo "        exporting init data to ${RESULT_PATH}/ifm30_init_data.dmp"  >>${LOG_FILE}  
        echo "        writting EXP_LOG to:${EXP_LOG}  "                           >>${LOG_FILE} 
    
        for line_table_name in `cat ${TABLE_NAME_FILE}`;
           do
           tbname=${IFM30USER}.$(echo ${line_table_name%,*}) ;
           exp ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} tables=${tbname}  file=${DMP_DIR}/${tbname}.dmp log=${EXP_LOG} silent=y statistics=none ;
          
           done  
 echo "        exp dmp file end  "                           >>${LOG_FILE} 
    ;;
    n|N|no|No|NO)
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}'"            >>${LOG_FILE}
        echo "        You chose not to export ifm30 init data"                 >>${LOG_FILE}
        echo "           Message:current step skipped,you chose not to export ifm30 init data." 
    ;;
    esac
    echo "        export ifm30 init data ended."                                  >>${LOG_FILE}
    echo "           step4 ended. "                                                 | tee -a  ${LOG_FILE}
}
 
# ###############################################################
#       exp_dbstuct
#       导出理财表结构
# ###############################################################

function exp_dbstuct {
    echo "Step 5: Export IFM30 DB Struct "                                        >>${LOG_FILE} 
    case ${EXP_INITDATA} in
        n|N|no|No|NO)
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}'"            >>${LOG_FILE}
        echo "        You chose not to export ifm30 table ddl"                   >>${LOG_FILE}
        echo "           Message:current step skipped,you chose not to export ifm30 table ddl."
    ;;
    y|Y|yes|Yes|YES)
    
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}' "           >>${LOG_FILE} 
        echo "        exporting table ddl to ${RESULT_PATH}/expdata"                >>${LOG_FILE}  
        echo "        writting EXP_LOG to:${EXP_LOG}  "                           >>${LOG_FILE} 
    # 导出表结构
cd ${INIT_DATA_PATH}
    
exp ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} file=${IFM30_TABLE_STRUCT} owner=${IFM30USER} rows=n log=${EXP_LOG};

    ;;
    esac
    echo "        export ifm30 table ddl ended."                                    >>${LOG_FILE}
    echo "           step5 ended. "                                                | tee -a  ${LOG_FILE}
}

# ###############################################################
#       分业务巡检方法
#       check_ifm30
# ###############################################################

function check_ifm30 {
   echo "Step 2: Check Business Data"                                     >>${LOG_FILE}
   #echo " "
if [ "${IS_CHECK_PUB}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_pub.html ifm30_xj_oracle_pub.sql pub
  # echo " "
fi

if [ "${IS_CHECK_FINA}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_fina.html ifm30_xj_oracle_fina.sql fina
   #echo " "
fi

if [ "${IS_CHECK_FUND}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_fund.html ifm30_xj_oracle_fund.sql fund
   #echo " "
fi

if [ "${IS_CHECK_YBT}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_ybt.html ifm30_xj_oracle_ybt.sql ybt
   #echo " "
fi

if [ "${IS_CHECK_METAL}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_metal.html ifm30_xj_oracle_metal.sql metal
   #echo " "
fi

if [ "${IS_CHECK_TRUST}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_trust.html ifm30_xj_oracle_trust.sql trust
  # echo " "
fi

if [ "${IS_CHECK_ZGDX}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_zgdx.html ifm30_xj_oracle_zgdx.sql zgdx
   #echo " "
fi
   echo "           step2 ended."                                            | tee -a  ${LOG_FILE}
}


# ###############################################################
#       总调用功能
#       
# ###############################################################
    # 修改字符集以便中文字符不乱码
    OLD_NLS_LANG=$NLS_LANG
    export NLS_LANG="simplified chinese_china.zhs16gbk"
    #export NLS_LANG=american_america.AL32UTF8
clear
init_param
connect_test
date_check
after_connect
clear
    HOSTNAME=$(hostname)
    BIT=$(getconf LONG_BIT)
    USER=`who am i | cut -d " " -f1`
    echo " "
    echo "======================================================== "    | tee -a  ${LOG_FILE}
    echo "                 IFM30 Oracle DB Check  "                       | tee -a  ${LOG_FILE}
    echo "    Hostname: $HOSTNAME "                                       >>${LOG_FILE}
    echo "    User: $USER  "                                              >>${LOG_FILE}
    echo "    Report Time: $(date +%Y'-'%m'-'%d' '%H':'%M':'%S)"          >>${LOG_FILE}
    echo "========================================================"       | tee -a  ${LOG_FILE}
    echo "         " 
    echo "BEGIN    "                                                      | tee -a ${LOG_FILE}
    echo "         "                                                      | tee -a ${LOG_FILE}
    #unset WCOLL
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step1: Initializing Directories"
        init_path
        
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step2: Checking Ifm30 Database"
        check_ifm30
        
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step3: Exporting Ifm30 ParamData "
        exp_param
        
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step4: Exporting Ifm30 InitData"
        exp_initdata 
    
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step5: Exporting Ifm30 Table DDL"
        exp_dbstuct
    echo " "  
    echo "END"                                                      | tee -a ${LOG_FILE}
    echo " "
    echo "All result files are in directory:"
    echo "${RESULT_PATH}"
    echo "----------------------------------------------------------"
    echo " "
export NLS_LANG=$OLD_NLS_LANG
unset OLD_NLS_LANG
