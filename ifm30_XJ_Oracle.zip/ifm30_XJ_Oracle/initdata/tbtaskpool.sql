col parent_task_code format a16
col task_page format a8
col task_type format a8
col redo_flag format a8
col delay_flag format a12
col delay_time format a12
col deal_status format a12
col stop_deal_flag format a16
col err_code format a10
col warn_flag format a12 

select ''''||market_code as market_code , 
       task_code, 
       task_name, 
       action_class, 
       serial_no, 
       parent_task_num, 
       parent_task_code, 
       task_page, 
       task_type, 
       task_row, 
       task_column, 
       redo_flag, 
       delay_flag, 
       delay_time, 
       op_code, 
       op_times, 
       deal_status, 
       stop_deal_flag, 
       excute_percentage, 
       err_code, 
       err_msg, 
       warn_flag, 
       warn_msg, 
       begin_time, 
       end_time, 
       hold_time, 
       last_trans_date, 
       trans_to_sub, 
       trans_to_sub2, 
       detail_url, 
       reserve1, 
       reserve2  
   from &1.tbtaskpool 
   order by market_code;