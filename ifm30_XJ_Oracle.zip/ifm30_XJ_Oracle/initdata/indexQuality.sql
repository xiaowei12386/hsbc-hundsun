SELECT i.table_name,t.num_rows,t.blocks,i.index_name,o.bytes/1048576 mb,i.avg_data_blocks_per_key,
        i.avg_leaf_blocks_per_key,i.clustering_factor,
        CASE
            WHEN NVL (i.clustering_factor, 0) = 0 THEN '0-No Stats'
            WHEN NVL (t.num_rows, 0) = 0 THEN '0-No Stats'
            WHEN (ROUND (i.clustering_factor / t.num_rows * 100)) < 6 THEN '5-Excellent'
            WHEN (ROUND (i.clustering_factor / t.num_rows * 100)) BETWEEN 7 AND 11 THEN '4-Very Good'
            WHEN (ROUND (i.clustering_factor / t.num_rows * 100)) BETWEEN 12 AND 15 THEN '2-Good'
            WHEN (ROUND (i.clustering_factor / t.num_rows * 100)) BETWEEN 16 AND 25 THEN '2-Fair'
            ELSE '1-Poor'
        END  
        index_quality
    FROM dba_indexes i, dba_segments o, dba_tables t
  WHERE 
        i.owner = t.owner
        AND i.table_name = t.table_name
        AND i.owner = o.owner
        AND i.index_name = o.segment_name
        AND t.owner ='&&1'     
ORDER BY table_name,num_rows,blocks,index_quality DESC;