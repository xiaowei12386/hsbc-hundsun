col belong_type format a12
col modi_flag format a10

select ''''||ta_code as ta_code , param_id, param_name, param_value, value_name, belong_type, modi_flag, reserve1  from &1.tbparam;