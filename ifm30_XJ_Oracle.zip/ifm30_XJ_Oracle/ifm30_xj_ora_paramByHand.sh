#!/bin/bash

:<<!
# ###############################################################

          综合理财平台 Oracle 巡检脚本（脚本参数配置版）
 
 操作系统：Linux,AIX
 数据库版本：Oracle 9i以上
 使用说明：
     1、必须结合initdata里的脚本一起使用。
     2、需要有执行权限。
     3、脚本直接执行前，需要修改输入参数。
     4、如果aix执行异常，或者命令不支持，请将开头的 #!/bin/bash 修改为 #!/bin/ksh
     
 脚本所属：恒生电子股份有限公司
     
# ###############################################################

!
# ###############################################################
#脚本正文：分模块处理
# ###############################################################
#       init_param
#       初始化参数配置
#
# 特别说明：参数配置的先后顺序请勿调整！！！
# ###############################################################

function init_param {

#-------------------------------手工配置参数 begin -------------------------------

# 脚本使用sqlplus命令连接数据库，建议先在终端试用该命令，试用成功再配置到脚本中
#################### 【1】配置查询数据库用户名和用户密码，可以不是ifm30用户 
# 该参数需要手工配置

DBCURUSR=ifm30

# 是否填入DES加密密文(y/n)，如果行里没有个性化，那db-config中加密的密码都是默认DES加密的
IS_SECRETPASSWORD=n

# 当前面选择加密的时候，这里需要填入加密后的密文，不加密则填入实际密码
DBUSRPWD=hundsun

###################### 【2】理财（ifm30）的用户名，schema以及数据库的监听服务名
# 该参数需要手工配置

IFM30USER=ifm30

# 是否需要服务名，如果需要则配置上，没有需要改为空，服务名前面要带@符号
DBSERVICE=@ora11g

###################### 【3】当前日期,取系统日期(无需修改) 
# 如果是要做历史周期巡检，则需要修改为过去的日期和年份

DATE=`date +%Y%m%d`
YEAR=`date +%Y`

###################### 【4】配置本次巡检开始日期、巡检结束日期 
# 只需要修改月和日

KSRQ=${YEAR}0101
JSRQ=${YEAR}0331

###################### 【5】配置本次巡检的业务，需要检查的业务配置为1
# 公共（默认检查）
IS_CHECK_PUB=1
# 理财
IS_CHECK_FINA=1
# 基金
IS_CHECK_FUND=1
# 银保
IS_CHECK_YBT=1
# 贵金属
IS_CHECK_METAL=1
# 信托
IS_CHECK_TRUST=1
# 资管代销
IS_CHECK_ZGDX=1

###################### 【6】是否统计客户量，交易量，金额等信息（敏感）0-不统计，1-统计
IS_STATISTICS=1

###################### 【7】是否需要导出平台基础参数
# 导出数据主要用来做公司镜像环境搭建使用，如果以前取过数据，那么无需再取
# yes-导出，no-不导出，默认为不导出

EXP_INITDATA=n

#-------------------------------手工配置参数 end -------------------------------

# 10、目录及文件名配置(往下一般无需改动)
    
# 获取当前目录
CUR_PATH=$(pwd)

# 初始化数据路径
INIT_DATA_PATH=${CUR_PATH}/initdata

# 脚本执行日志文件
LOG_FILE=${CUR_PATH}/xj_ifm30_ora_${DATE}.log

# 结果文件存放目录
RESULT_PATH=${CUR_PATH}/XJ_OraResult

# 初始化数据导出日志
EXP_LOG=${CUR_PATH}/inidata_exp.log

# 数据检查结果文件
#REPORT_FILE=${RESULT_PATH}/oracle_ifm30_report.html

# 导出基础数据表名文件
TABLE_NAME_FILE=${INIT_DATA_PATH}/exp_tables.txt

# 基础数据导出目录
EXP_DIR=${RESULT_PATH}/expdata  
     
# 基础数据导出目录
DMP_DIR=${RESULT_PATH}/expdata/dmp 

# 表结构文件 
IFM30_TABLE_STRUCT=${RESULT_PATH}/expdata/ifm30_table_struct.dmp

# 理财用户名小写转大写
IFM30USER=`echo ${IFM30USER} | tr '[:lower:]' '[:upper:]'`

rm -f ${LOG_FILE}
rm -f ${EXP_LOG}
touch ${LOG_FILE}

echo "  1.Initializing parameters ..."
# 参数判空
if [ "$DBCURUSR" == "" ]; then
   echo " "
   echo "DBCURUSR is null! Please check."
   echo " "
   exit;
fi

if [ "$IS_SECRETPASSWORD" == "" ]; then
   echo " "
   echo "IS_SECRETPASSWORD is null! Please check."
   echo " "
   exit;
fi

if [ "$DBUSRPWD" == "" ]; then
   echo " "
   echo "DBUSRPWD is null! Please check."
   echo " "
   exit;
fi

if [ "$IFM30USER" == "" ]; then
   echo " "
   echo "IFM30USER is null! Please check."
   echo " "
   exit;
fi

}

# ###############################################################
#       connect_test
#       用户登录合法性测试
# ###############################################################

function connect_test {
#echo "   "
echo "  2.Initializing database connection ..."
   if [ "$DBUSRPWD" == "" ]; then
      echo " "
      echo "Your password is null! Please enter the password."
       echo " "
      exit;
     fi
     
case ${IS_SECRETPASSWORD} in
    y|Y|yes|Yes|YES)

 DECRYPT_RESULT=$(java -jar ${INIT_DATA_PATH}/dbconfigtool.jar ${DBUSRPWD}  | tail -1 ) 
 DECRYPT_FLAG=$(echo ${DECRYPT_RESULT%//*})
 if [ ${DECRYPT_FLAG} == "Success" ]
 then
   DBUSRPWD=$(echo ${DECRYPT_RESULT#*//})
 
 else
     echo "ERROR:password decrypt fail !"
     echo "  "     
     exit;
 fi
    ;;
    n|N|no|No|NO)

    ;;
    esac
echo "    ended"
echo "  3.Testing database connection ..."
echo "    $(echo show user | sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE})"

CONN_S=$(echo $(echo "select 'TRUE' from dual;" | sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} | grep -i 'TRUE' | wc -l))

#echo ${CONN_S}

if [ "$CONN_S" == "1" ]
then
 echo "    Connection success !" 
#   exit;
 else
   echo "    ERROR:Connection fail !"
   echo "  "
   exit;
fi
echo "    ended"
}

# ###############################################################
#       date_check
#       日期合法性测试
# ###############################################################

function date_check {
echo "  4.Checking date legitimacy ..."
len1=$(echo ${#KSRQ})
len2=$(echo ${#JSRQ})
if [ "$len1" -ne 8 ]
then
   echo "    Error:Format error: Start date lenth !=8  "
#   exit;
fi
if [ "$len2" -ne 8 ]
then
    echo "    Error:Format error: End date lenth !=8  "
#   exit;

fi
if [ "$KSRQ" -ge "$JSRQ" ]
then
    echo "    Error:Start date >= End date "
#   exit;

fi
echo "    ended"
}

# ###############################################################
#       init_path
#       初始化路径
# ###############################################################

function init_path {

    # 为支持重复执行，先删除前一次执行的结果
    # 创建检查结果存放目录 beg
    echo "Step 1: Create Resuilt File Dir "                          >>${LOG_FILE}
    echo "        creating dir:${RESULT_PATH} ..."                   >>${LOG_FILE}    
    if [  -d "${RESULT_PATH}" ]; 
        then
        echo "        dir exists."                                   >>${LOG_FILE}
        echo "        trying to remove it and rebuild the dir... "   >>${LOG_FILE}       
        rm -rf ${RESULT_PATH}    
        mkdir  ${RESULT_PATH}        
        else      
        echo "        dir not exist,trying to create it..."           >>${LOG_FILE}         
        mkdir ${RESULT_PATH}
    fi
        echo "        dir ${RESULT_PATH} created!"                    >>${LOG_FILE}
        mkdir  ${EXP_DIR}
        echo "        dir ${EXP_DIR} created!"                        >>${LOG_FILE}
        mkdir  ${DMP_DIR}
        echo "        dir ${DMP_DIR} created!"                        >>${LOG_FILE}
    echo "           step1 ended."                                      | tee -a  ${LOG_FILE}
}

# ###############################################################
#       sub_ifm30
#       具体业务数据检查
# ###############################################################

    # 理财系统数据检查 beg
function sub_ifm30 {
	RESULT_FILE=${RESULT_PATH}/$1
	SQL_FILE=$2
	CHECK_BUSINESS=$3
    echo "           Check Business: ${CHECK_BUSINESS}"                   | tee -a  ${LOG_FILE}
    echo "        writting resuilt to: ${RESULT_PATH} "                    >>${LOG_FILE}
    echo "        usinging basesql from: ${SQL_FILE} "                     >>${LOG_FILE}
    sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} <<EOF                   >>${LOG_FILE} 

set term off termout off verify off feedback off echo off heading on pagesize 999 
set markup html on  spool on PREFORMAT OFF ENTMAP Off -
HEAD  '<TITLE> IFM30 DB Report </TITLE> -
<style type="text/css"> -
  body{font-family:Microsoft YaHei,sans-serif;font-size: 12px;line-height:140%;color:#333333; WORD-WRAP:break-word;}-
  h0 {margin:5px 0px 5px 0px;font-size:30px;line-height:32px;font-weight:900;}-
  h1 {margin:5px 0px 5px 0px;font-size:20px;line-height:22px;}-
  h2 {margin:10px 0px 5px 0px;font-size:18px;line-height:20px;}-
  h3 {margin:10px 0px 5px 0px;font-size:16px;line-height:18px;}-
  h4 {margin:10px 0px 5px 0px;font-size:14px;line-height:16px;color:#CD4F39;}-
  p  {margin:10px 0px 5px 0px;padding:0;font-size: 10px;line-height:16px;color:#B22222;}-
  hr.level1{height: 2px;;width:100%;background:#EECFA1;}-
  a {color:#1874CD}-
  br{ display:inline; line-height:5px;} -
  div{margin:0px 0px 0px 0px;color: #333333;line-height:20px;}-
  div.level1{margin:0px 0px 0px 0px;color: #333333;line-height:20px;}-
  ul.level2{list-style-type:square;line-height:18px; }- 
  ul.level3{list-style-type:square;list-style-position: inside;font-size: 12px;line-height:14px;color:#EE5C42;}-  
  table {align:left;font-family: arial, sans-serif;font-size: 12px;line-height:100%;color: #333333;border-width: 1px;border-color: #3A3A3A;border-collapse: collapse;}-
  th {border-width: 1px;padding: 4px;border-style: solid;border-color: #517994;background-color:#B2CFD8;}-
  tr:hover td {background-color:#DFEBF1;}-
  td {border-width: 1px;padding: 4px;border-style: solid;border-color: #517994;background-color:#ffffff;-
  }-
</style>' -
BODY "" -
TABLE "border='1' width='0' " -

spool ${RESULT_FILE}
@${INIT_DATA_PATH}/${SQL_FILE}
${IFM30USER}.
${IS_STATISTICS}
${YEAR}
${KSRQ}
${JSRQ}
${IFM30USER}
spool off;
set markup html off;
exit;
EOF
    echo "           checking business ${CHECK_BUSINESS} ended"                 | tee -a  ${LOG_FILE}

}

# ###############################################################
#       exp_param
#       导出相关配置信息
# ###############################################################

    # 导出相关配置信息 beg
    function exp_param {

    echo "Step 3: Export Param To Excel "                            >>${LOG_FILE}
    cd ${INIT_DATA_PATH}
    echo "        generating files to:${RESULT_PATH} "               >>${LOG_FILE}
    echo "        usinging basesql from: ${INIT_DATA_PATH} "         >>${LOG_FILE}
    sqlplus -S ${DBCURUSR}/${DBUSRPWD}${DBSERVICE}  <<EOF1     >>${LOG_FILE} 2>&1
set term off termout off verify off feedback off pagesize 999 
set markup html on entmap ON spool on preformat off

prompt --------exporting tbtaskpool to tbtaskpool.xls
spool ${RESULT_PATH}/tbtaskpool.xls;
@tbtaskpool.sql ${IFM30USER}.
spool off;

prompt --------exporting tbparam to tbparam.xls
spool ${RESULT_PATH}/tbparam.xls;
@tbparam.sql ${IFM30USER}.
spool off;

prompt --------exporting index to index.xls
spool ${RESULT_PATH}/index.xls;
@index.sql ${IFM30USER}
spool off;

prompt --------exporting indexQuality to indexQuality.xls 
spool ${RESULT_PATH}/indexQuality.xls;
@indexQuality.sql ${IFM30USER}
spool off;

exit;
EOF1

echo "        export param table ended"                          >>${LOG_FILE}
echo "           step3 ended."                                    | tee -a  ${LOG_FILE}
}

# ###############################################################
#       exp_initdata
#       导出理财初始化数据
# ###############################################################

    # 导出理财初始化数据 beg
    function exp_initdata {
    echo "Step 4: Export IFM30 Init Data "                                        >>${LOG_FILE}
    case ${EXP_INITDATA} in
    y|Y|yes|Yes|YES)  
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}' "           >>${LOG_FILE} 
        echo "        exporting init data to ${RESULT_PATH}/ifm30_init_data.dmp"  >>${LOG_FILE}  
        echo "        writting EXP_LOG to:${EXP_LOG}  "                           >>${LOG_FILE}   
        for line_table_name in `cat ${TABLE_NAME_FILE}`;
           do
           tbname=${IFM30USER}.$(echo ${line_table_name%,*}) ;
           exp ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} tables=${tbname}  file=${DMP_DIR}/${tbname}.dmp log=${EXP_LOG} silent=y statistics=none ;        
           done  
 echo "        exp dmp file end  "                           >>${LOG_FILE} 
    ;;
    n|N|no|No|NO)
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}'"            >>${LOG_FILE}
        echo "        You chose not to export ifm30 init data"                 >>${LOG_FILE}
        echo "           Message:current step skipped,you chose not to export ifm30 init data." 
    ;;
    esac
    echo "        export ifm30 init data ended."                                  >>${LOG_FILE}
    echo "           step4 ended. "                                                 | tee -a  ${LOG_FILE}
}
 
# ###############################################################
#       exp_dbstuct
#       导出理财表结构
# ###############################################################

function exp_dbstuct {
    echo "Step 5: Export IFM30 DB Struct "                                        >>${LOG_FILE}
    case ${EXP_INITDATA} in
        n|N|no|No|NO)
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}'"            >>${LOG_FILE}
        echo "        You chose not to export ifm30 table ddl"                   >>${LOG_FILE}
        echo "           Message:current step skipped,you chose not to export ifm30 table ddl."
    ;;
    y|Y|yes|Yes|YES)   
        echo "        param 'EXP_INITDATA' value is '${EXP_INITDATA}' "           >>${LOG_FILE} 
        echo "        exporting table ddl to ${RESULT_PATH}/expdata"                >>${LOG_FILE}  
        echo "        writting EXP_LOG to:${EXP_LOG}  "                           >>${LOG_FILE} 
    # 导出表结构
cd ${INIT_DATA_PATH}  
exp ${DBCURUSR}/${DBUSRPWD}${DBSERVICE} file=${IFM30_TABLE_STRUCT} owner=${IFM30USER} rows=n log=${EXP_LOG};
    ;;
    esac
    echo "        export ifm30 table ddl ended."                                    >>${LOG_FILE}
    echo "           step5 ended. "                                                | tee -a  ${LOG_FILE}
}

# ###############################################################
#       分业务巡检方法
#       check_ifm30
# ###############################################################

function check_ifm30 {
   echo "Step 2: Check Business Data"                                     >>${LOG_FILE}
   #echo " "
if [ "${IS_CHECK_PUB}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_pub.html ifm30_xj_oracle_pub.sql pub
  # echo " "
fi

if [ "${IS_CHECK_FINA}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_fina.html ifm30_xj_oracle_fina.sql fina
   #echo " "
fi

if [ "${IS_CHECK_FUND}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_fund.html ifm30_xj_oracle_fund.sql fund
   #echo " "
fi

if [ "${IS_CHECK_YBT}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_ybt.html ifm30_xj_oracle_ybt.sql ybt
   #echo " "
fi

if [ "${IS_CHECK_METAL}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_metal.html ifm30_xj_oracle_metal.sql metal
   #echo " "
fi

if [ "${IS_CHECK_TRUST}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_trust.html ifm30_xj_oracle_trust.sql trust
   #echo " "
fi

if [ "${IS_CHECK_ZGDX}" == "1" ]; then
   #echo " "
   sub_ifm30 oracle_ifm30_zgdx.html ifm30_xj_oracle_zgdx.sql zgdx
   #echo " "
fi
   echo "           step2 ended."                                            | tee -a  ${LOG_FILE}
}



# ###############################################################
#       总调用功能
#       
# ###############################################################
    # 修改字符集以便中文字符不乱码
    OLD_NLS_LANG=$NLS_LANG
    export NLS_LANG="simplified chinese_china.zhs16gbk"
    #export NLS_LANG=american_america.AL32UTF8
clear
echo " "
echo "Initializing ..."
echo " "
init_param
connect_test
date_check
#echo "end"
#clear
    HOSTNAME=$(hostname)
    BIT=$(getconf LONG_BIT)
    USER=`who am i | cut -d " " -f1`
    echo " "
    echo "======================================================== "    | tee -a  ${LOG_FILE}
    echo "                 IFM30 Oracle DB Check  "                       | tee -a  ${LOG_FILE}
    echo "    Hostname: $HOSTNAME "                                       >>${LOG_FILE}
    echo "    User: $USER  "                                              >>${LOG_FILE}
    echo "    Report Time: $(date +%Y'-'%m'-'%d' '%H':'%M':'%S)"          >>${LOG_FILE}
    echo "========================================================"       | tee -a  ${LOG_FILE}
    echo "         " 
    echo "BEGIN    "                                                      | tee -a ${LOG_FILE}
    echo "         "                                                      | tee -a ${LOG_FILE}
    #unset WCOLL
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step1: Initializing Directories"
        init_path
        
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step2: Checking Ifm30 Database"
        check_ifm30
        
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step3: Exporting Ifm30 ParamData "
        exp_param
        
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step4: Exporting Ifm30 InitData"
        exp_initdata 
    
    echo "\n --------------------------------------------------------\n"  >> ${LOG_FILE}
    echo "    Step5: Exporting Ifm30 Table DDL"
        exp_dbstuct
    echo " "  
    echo "END"                                                      | tee -a ${LOG_FILE}
    echo " "
    echo "All result files are in directory:"
    echo "${RESULT_PATH}"
    echo "----------------------------------------------------------"
    echo " "
export NLS_LANG=$OLD_NLS_LANG
unset OLD_NLS_LANG
#-------------------------end---------------------------------------------------------------------------



